//
//  Details_View.swift
//  NEWS_reading
//
//  Created by Анастасія Локайчук on 01.07.2022.
//
import SwiftUI

struct ResortDetails: View
{
    @ObservedObject var newsList = GetNewsData()
    var size :String
    {
        switch resort.size
        {
        case 1:
            return "Small"
        case 2:
            return "Average"
        default:
            return "Large"
        }
    }
    var price: String
    {
        String(repeating: "$", count: resort.price)
    }
    var body: some View {
        Group
        {
            VStack
            {
                Text("size")
                    .font(.caption.bold())
                Text("\(size)").font(.title3)
                
            }
            VStack
            {
                Text("Price").font(.caption.bold())
                Text(price).font(.title3)
            }
        }
        .frame(maxWidth: .infinity)
    }
}

struct ResortDetails_Previews: PreviewProvider {
    static var previews: some View {
        ResortDetails()
    }
}

