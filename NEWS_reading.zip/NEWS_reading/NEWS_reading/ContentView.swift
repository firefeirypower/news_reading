import SwiftUI

struct HomeView: View {
    @ObservedObject var newsList = GetNewsData()
    @State private var SearchText = ""
    var body: some View
    {
        NavigationView
        {
            List(filtredNews)
            {
                news in
                NavigationLink
                {
                    Information_View(news: news)
                }
            label:
                {
                    VStack(alignment: .leading)
                    {
                        Text(news.title).font(.headline)
                        Text(news.description).font(.caption)
                    }.padding()
                }
            }
            .navigationBarTitle(Text("News"))
            .font(.title)
            .searchable(text: $SearchText,prompt: "Search for a titles")
        }
    }
    var filtredNews : [NewsDataType]
    {
        if SearchText.isEmpty
        {
            return newsList.newsDatas
        }else
        {
            return newsList.newsDatas.filter{$0.title.localizedCaseInsensitiveContains(SearchText)}
        }
    }
    


}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
