import Foundation

struct NewsDataType: Identifiable
{
    var id: String
    var author : String
    var title: String
    var description: String
    var image: String
    var url: String
    var publishedAt : String
}
