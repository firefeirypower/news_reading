import SwiftUI
import SDWebImageSwiftUI

struct Information_View: View
{
    @ObservedObject var newsList = GetNewsData()
    let news : NewsDataType
    
    var body: some View
    {
        ScrollView
        {
            VStack(alignment: .leading, spacing: 0)
            {
                Text(news.title).font(.title3.bold()).padding()
                if news.image != ""
                {
                    WebImage(url: URL(string: news.image), options: .highPriority, context: nil)
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .cornerRadius(12)
                        .scaledToFit()
                }
                Group
                {
                    Text(news.description)
                            .padding(.vertical)
                    Text(news.author).font(.caption.bold())
                    Text(news.publishedAt).font(.caption.bold())
                }
                .padding(.horizontal)
            }
        }
    }
    
}



