//
//  NEWS_readingApp.swift
//  NEWS_reading
//
//  Created by Анастасія Локайчук on 01.07.2022.
//

import SwiftUI

@main
struct NEWS_readingApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
        }
    }
}
