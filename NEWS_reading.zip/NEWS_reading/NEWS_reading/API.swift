import Foundation
import SwiftUI
import SwiftyJSON

class GetNewsData: ObservableObject {
    @Published var newsDatas = [NewsDataType]()
    
    init()
    {
        let sourceOfNews = "https://newsapi.org/v2/top-headlines?country=us&category=business&apiKey=8f5f78315d324575ab9b7b38cf96be34"
        
        let url = URL(string: sourceOfNews)!
        
        let session = URLSession(configuration: .default)
        
        session.dataTask(with: url) {
            (data, _, error) in
            
            if error != nil {
                print((error?.localizedDescription)!)
                return
            }
            
            let json = try! JSON(data: data!)
            
            for index in json["articles"] {
                let id = index.1["publishedAt"].stringValue
                let title = index.1["title"].stringValue
                let description = index.1["description"].stringValue
                let image = index.1["urlToImage"].stringValue
                let url = index.1["url"].stringValue
                let author = index.1["author"].stringValue
                let publishedAt = index.1["publishedAt"].stringValue
                
                DispatchQueue.main.async {
                    self.newsDatas.append(NewsDataType(id: id, author: author, title: title, description: description,image: image, url: url, publishedAt : publishedAt))
                }
            }
        }.resume()
    }
}
